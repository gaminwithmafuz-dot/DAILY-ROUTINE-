package com.dailyroutine.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray

object Scheduler {
    private const val PREFS = "sched"
    private const val KEY = "list"
    private const val TEST_ID = 999999

    private fun intentFor(ctx: Context, title: String?, body: String?) =
        Intent(ctx, AlarmReceiver::class.java).apply {
            if (title != null) putExtra("title", title)
            if (body != null) putExtra("body", body)
        }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Replace every alarm with the list the web page just computed. */
    fun schedule(ctx: Context, json: String) {
        cancelAll(ctx)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
        setAll(ctx, json)
    }

    /** Called after a reboot / update / time change. */
    fun restore(ctx: Context) {
        val json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return
        setAll(ctx, json)
    }

    private fun cancelAll(ctx: Context) {
        val old = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return
        val am = ctx.getSystemService(AlarmManager::class.java)
        val arr = JSONArray(old)
        for (i in 0 until arr.length()) {
            val id = arr.getJSONObject(i).getInt("id")
            val pi = PendingIntent.getBroadcast(
                ctx, id, intentFor(ctx, null, null),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
    }

    private fun setAll(ctx: Context, json: String) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = showIntent(ctx)
        val now = System.currentTimeMillis()
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.getLong("t")
            if (t <= now) continue
            val pi = PendingIntent.getBroadcast(
                ctx, o.getInt("id"),
                intentFor(ctx, o.optString("title"), o.optString("body")),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // setAlarmClock is exempt from Doze and works with the screen off.
            am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi)
        }
    }

    fun test(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, TEST_ID, intentFor(ctx, "🔔 টেস্ট অ্যালার্ম", "সব ঠিক আছে — অ্যালার্ম কাজ করছে ✅"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 5000, showIntent(ctx)), pi)
    }
}
