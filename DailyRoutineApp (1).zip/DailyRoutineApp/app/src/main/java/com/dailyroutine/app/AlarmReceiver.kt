package com.dailyroutine.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Daily Routine"
        val body = intent.getStringExtra("body") ?: ""
        Notifier.show(context, title, body)
    }
}
